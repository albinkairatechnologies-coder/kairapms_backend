from flask import Flask
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from dotenv import load_dotenv
import os

from app.routes.auth import auth_bp
from app.routes.clients import client_bp
from app.routes.tasks import task_bp
from app.routes.other import other_bp
from app.routes.dashboard import dashboard_bp
from app.routes.org import org_bp
from app.routes.reports import reports_bp

load_dotenv()

app = Flask(__name__)
app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'kairaflow-secret')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

CORS(app)
jwt = JWTManager(app)

app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(client_bp, url_prefix='/api')
app.register_blueprint(task_bp, url_prefix='/api')
app.register_blueprint(other_bp, url_prefix='/api')
app.register_blueprint(dashboard_bp, url_prefix='/api')
app.register_blueprint(org_bp, url_prefix='/api')
app.register_blueprint(reports_bp, url_prefix='/api')

@app.route('/')
def index():
    return {"message": "KairaFlow API is running"}, 200

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)

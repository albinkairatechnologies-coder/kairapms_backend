from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt
from app.models.user import User
from app.utils.auth import verify_password, generate_token

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    user = User.get_by_email(data['email'])
    if not user or not verify_password(data['password'], user['password']):
        return jsonify({"error": "Invalid credentials"}), 401
    token = generate_token(user['id'], user['role'])
    return jsonify({
        "token": token,
        "user": {
            "id": user['id'],
            "name": user['name'],
            "email": user['email'],
            "role": user['role'],
            "team_id": user.get('team_id'),
            "department_id": user.get('department_id'),
            "manager_id": user.get('manager_id')
        }
    }), 200

@auth_bp.route('/me', methods=['GET'])
@jwt_required()
def get_current_user():
    user_id = int(get_jwt_identity())
    user = User.get_by_id(user_id)
    if user:
        return jsonify(user), 200
    return jsonify({"error": "User not found"}), 404

@auth_bp.route('/users', methods=['GET'])
@jwt_required()
def get_users():
    role = request.args.get('role')
    team_id = request.args.get('team_id')
    department_id = request.args.get('department_id')
    users = User.get_all(
        role=role,
        team_id=int(team_id) if team_id else None,
        department_id=int(department_id) if department_id else None
    )
    return jsonify(users), 200

@auth_bp.route('/register', methods=['POST'])
@jwt_required()
def register():
    claims = get_jwt()
    if claims['role'] != 'admin':
        return jsonify({"error": "Unauthorized"}), 403
    data = request.json
    try:
        user_id = User.create(
            name=data['name'],
            email=data['email'],
            password=data['password'],
            role=data['role'],
            phone=data.get('phone'),
            team_id=int(data['team_id']) if data.get('team_id') else None,
            department_id=int(data['department_id']) if data.get('department_id') else None,
            manager_id=int(data['manager_id']) if data.get('manager_id') else None
        )
        return jsonify({"message": "User created", "user_id": user_id}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400

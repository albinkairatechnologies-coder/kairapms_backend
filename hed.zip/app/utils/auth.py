from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import create_access_token
from datetime import timedelta

def hash_password(password):
    return generate_password_hash(password)

def verify_password(password, hashed):
    return check_password_hash(hashed, password)

def generate_token(user_id, role):
    return create_access_token(
        identity=str(user_id),
        additional_claims={"role": role},
        expires_delta=timedelta(days=7)
    )
